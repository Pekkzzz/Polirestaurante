using Microsoft.AspNetCore.Mvc;
using PoliRestaurante.Models;

namespace ApiEcommerce.Controllers
{
  [Route("api/[controller]")] // EVAN: Requeriment RF-12
  [ApiController]
  public class UserRoleController : ControllerBase
  {
    private readonly IUserRoleService _service;

    public UserRoleController(IUserRoleService userRoleService)
    {
      _service = userRoleService;
    }

    //This is for get a specific userRole
    [HttpGet("{id:int}", Name = "GetUserRoleByID")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetUserRoleByID(int id)
    {
        UserRoleService_Response userRoleService_Response = _service.GetByID(id);
        if (!userRoleService_Response.Response && userRoleService_Response.userRole == null)
        {
          return NotFound(userRoleService_Response.Description);
          
        }
        return Ok(userRoleService_Response.userRole);
    }

    [HttpGet(Name = "GetAll")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult GetAll()
    {
      UserRoleService_Response serviceResponse = _service.GetAll();

        if (!serviceResponse.Response || serviceResponse.userRoles == null)
        {
            ModelState.AddModelError("CustomError", serviceResponse.Description);
            return BadRequest(ModelState);
        }

        var objects = serviceResponse.userRoles
            .Select(objectToConvert => UsersMapper.UserRoleToDto(objectToConvert))
            .ToList();

        return Ok(objects);
    }
    
    [HttpPost]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult CreateUserRole([FromBody] UserRole_CreateDto createUserRoleDto)
    {
      if (createUserRoleDto == null)
      {
        return BadRequest(ModelState);
      }
      UserRoleService_Response userRoleService_Response = _service.Create(createUserRoleDto);
      if (!userRoleService_Response.Response || userRoleService_Response.userRole == null)
      {
        ModelState.AddModelError("CustomError", userRoleService_Response.Description);
        return StatusCode(500, ModelState);
      }
      else
      {
        return CreatedAtRoute("GetUserRoleByID", new { id = userRoleService_Response.userRole.Id }, userRoleService_Response.userRole);
      }

      
    }

    [HttpPatch(Name = "UpdateUserRole")]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult UpdateUser([FromBody] UserRole_UpdateDto updateUserRoleDto)
    {
      if (updateUserRoleDto == null)
      {
        return BadRequest(ModelState);
      }
      UserRoleService_Response serviceResponse = _service.Update(updateUserRoleDto);

      if (!serviceResponse.Response || serviceResponse.userRole == null)
      {
        ModelState.AddModelError("CustomError", serviceResponse.Description);
        return BadRequest(ModelState);
      }

      UserRole_Dto userRole_Dto = UsersMapper.UserRoleToDto(serviceResponse.userRole);
      return Ok(userRole_Dto);
    }

    [HttpDelete("{id:int}", Name = "DeleteUserRoleByID")]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult DeleteUser(int id)
    {
      UserRoleService_Response serviceResponse = _service.Delete(id);
      if (!serviceResponse.Response)
      {
        ModelState.AddModelError("CustomError", serviceResponse.Description);
        return BadRequest(ModelState);
      }
      return Ok();
    }

    
  }
}