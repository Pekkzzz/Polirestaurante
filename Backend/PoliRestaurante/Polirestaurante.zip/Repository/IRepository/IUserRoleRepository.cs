using PoliRestaurante.Models.Entity;

public interface IUserRoleRepository
{
  bool CreateUserRole(UserRole userRole);
  UserRole? GetUserRole(int id);
  UserRole? GetUserRole(string name);
  List<UserRole>? GetAll();
  bool UserRoleExists(int id);
  bool UserRoleExists(string name);
  bool UpdateUserRole(UserRole userRole);
  bool DeleteUserRole(UserRole userRole);
}