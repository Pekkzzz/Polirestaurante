using PoliRestaurante.Models.Entity;

public interface IOrderRepository
{
  bool Create(Order Order);
  Order? Get(int id);
  List<Order>? GetAll();
  bool Exists(int id);
  bool Update(Order Order);
  bool Delete(Order Order);
  
}