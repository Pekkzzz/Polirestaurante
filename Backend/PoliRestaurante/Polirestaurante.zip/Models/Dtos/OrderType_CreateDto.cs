public partial class OrderType_CreateDto
{
    public string Name { get; set; } = null!;

    public string Description { get; set; } = null!;
}